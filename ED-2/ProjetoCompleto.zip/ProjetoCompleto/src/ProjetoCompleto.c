/*
 ============================================================================
 Name        : ProjetoCompleto.c
 Author      : IHMHR
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include "lista.h"

typedef struct pilha Tpilha;

struct pilha
{
	Tlista *topo;
};

Tpilha* inicializarPilha()
{
	Tpilha *aux = (Tpilha*) malloc(sizeof(Tpilha));
	aux->topo = NULL;
	return aux;
}

void pushPilha(Tpilha *pilha, char letra)
{
	pilha->topo = inserir(pilha->topo, letra);
}

void imprimirPilha(Tpilha *pilha)
{
	imprime(pilha->topo);
}

void popPilha(Tpilha *pilha)
{
	pilha->topo = removeLista(pilha->topo, pilha->topo->dado);
}

void liberaPilha(Tpilha *pilha)
{
	pilha->topo = liberaCircular(pilha->topo);
}

int main()
{
	Tpilha *pilhaUsuario = inicializarPilha();

	pushPilha(pilhaUsuario, 'F');
	pushPilha(pilhaUsuario, 'A');
	pushPilha(pilhaUsuario, 'C');
	pushPilha(pilhaUsuario, 'E');

	imprimirPilha(pilhaUsuario);

	popPilha(pilhaUsuario);
	printf("\n");

	imprimirPilha(pilhaUsuario);

	liberaPilha(pilhaUsuario);
	printf("\n");

	imprimirPilha(pilhaUsuario);

	return 0;
}
